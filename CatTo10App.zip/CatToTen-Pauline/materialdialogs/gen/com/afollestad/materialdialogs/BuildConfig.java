/** Automatically generated file. DO NOT MODIFY */
package com.afollestad.materialdialogs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}