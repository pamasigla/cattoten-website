package com.afollestad.materialdialogs;

/**
 * @author Aidan Follestad (afollestad)
 */
public enum Alignment {
    LEFT, CENTER, RIGHT
}
